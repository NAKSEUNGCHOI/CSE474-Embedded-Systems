var searchData=
[
  ['display_5fsegment_0',['display_segment',['../_demo4_8ino.html#a1e49f538059ec05fa3921fa26456f418',1,'display_segment(byte temp[7]):&#160;Demo4.ino'],['../_s_r_r_i4_8h.html#a1e49f538059ec05fa3921fa26456f418',1,'display_segment(byte temp[7]):&#160;Demo4.ino']]]
];
