var searchData=
[
  ['convert_0',['convert',['../_demo4_8ino.html#addd1910538681ce843637531e10d7bec',1,'convert(int *digits, int count):&#160;Demo4.ino'],['../_s_r_r_i4_8h.html#addd1910538681ce843637531e10d7bec',1,'convert(int *digits, int count):&#160;Demo4.ino']]]
];
