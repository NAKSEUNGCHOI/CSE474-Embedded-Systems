var searchData=
[
  ['schedule_5fsync_0',['schedule_sync',['../_demo4_8ino.html#aa795a3f5ae7c3378d219ad1ca83a282d',1,'schedule_sync():&#160;Demo4.ino'],['../_s_r_r_i4_8h.html#aa795a3f5ae7c3378d219ad1ca83a282d',1,'schedule_sync():&#160;Demo4.ino']]],
  ['set_5foc3a_5ffreq_1',['set_OC3A_freq',['../_demo4_8ino.html#a520643fae9a5bb426c0c6d4affa68a01',1,'set_OC3A_freq(uint32_t freq):&#160;Demo4.ino'],['../_s_r_r_i4_8h.html#a520643fae9a5bb426c0c6d4affa68a01',1,'set_OC3A_freq(uint32_t freq):&#160;Demo4.ino']]],
  ['setup_2',['setup',['../_demo4_8ino.html#a4fc01d736fe50cf5b977f755b675f11d',1,'Demo4.ino']]],
  ['seven_5fsegment_5fsetup_3',['seven_segment_setup',['../_demo4_8ino.html#a338e9711e5868874ef44a65a1c6ce5b0',1,'seven_segment_setup():&#160;Demo4.ino'],['../_s_r_r_i4_8h.html#a338e9711e5868874ef44a65a1c6ce5b0',1,'seven_segment_setup():&#160;Demo4.ino']]],
  ['sleep_5f474_4',['sleep_474',['../_demo4_8ino.html#ad918c622cb258b19335463109f0b7996',1,'sleep_474(long t):&#160;Demo4.ino'],['../_s_r_r_i4_8h.html#ad918c622cb258b19335463109f0b7996',1,'sleep_474(long t):&#160;Demo4.ino']]],
  ['speaker_5fsetup_5',['speaker_setup',['../_demo4_8ino.html#ae9b4ac841df7c446aec94564e5a75c95',1,'speaker_setup():&#160;Demo4.ino'],['../_s_r_r_i4_8h.html#ae9b4ac841df7c446aec94564e5a75c95',1,'speaker_setup():&#160;Demo4.ino']]]
];
