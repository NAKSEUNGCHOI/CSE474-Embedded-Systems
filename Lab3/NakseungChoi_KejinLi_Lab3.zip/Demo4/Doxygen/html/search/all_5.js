var searchData=
[
  ['task1_0',['Task1',['../_demo4_8ino.html#a981008700b24339f2f3510a01188a336',1,'Task1():&#160;Demo4.ino'],['../_s_r_r_i4_8h.html#a981008700b24339f2f3510a01188a336',1,'Task1():&#160;Demo4.ino']]],
  ['task2_1',['Task2',['../_demo4_8ino.html#a48ca17e52cd2a385f36d93d00e135083',1,'Task2():&#160;Demo4.ino'],['../_s_r_r_i4_8h.html#a48ca17e52cd2a385f36d93d00e135083',1,'Task2():&#160;Demo4.ino']]],
  ['task3_2',['Task3',['../_demo4_8ino.html#a1d00ae2cc8d58d5922cbf8af0e4e53b0',1,'Task3():&#160;Demo4.ino'],['../_s_r_r_i4_8h.html#a1d00ae2cc8d58d5922cbf8af0e4e53b0',1,'Task3():&#160;Demo4.ino']]]
];
