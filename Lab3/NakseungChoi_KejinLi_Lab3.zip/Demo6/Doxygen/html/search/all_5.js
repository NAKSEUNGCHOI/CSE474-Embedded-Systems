var searchData=
[
  ['schedule_5fsync_0',['schedule_sync',['../_d_d_s6_8h.html#aa795a3f5ae7c3378d219ad1ca83a282d',1,'schedule_sync():&#160;Demo6.ino'],['../_demo6_8ino.html#aa795a3f5ae7c3378d219ad1ca83a282d',1,'schedule_sync():&#160;Demo6.ino']]],
  ['set_5foc3a_5ffreq_1',['set_OC3A_freq',['../_d_d_s6_8h.html#a520643fae9a5bb426c0c6d4affa68a01',1,'set_OC3A_freq(uint32_t freq):&#160;Demo6.ino'],['../_demo6_8ino.html#a520643fae9a5bb426c0c6d4affa68a01',1,'set_OC3A_freq(uint32_t freq):&#160;Demo6.ino']]],
  ['setup_2',['setup',['../_demo6_8ino.html#a4fc01d736fe50cf5b977f755b675f11d',1,'Demo6.ino']]],
  ['seven_5fsegment_5fsetup_3',['seven_segment_setup',['../_demo6_8ino.html#a338e9711e5868874ef44a65a1c6ce5b0',1,'Demo6.ino']]],
  ['sleep_5f474_4',['sleep_474',['../_d_d_s6_8h.html#ad918c622cb258b19335463109f0b7996',1,'sleep_474(long t):&#160;Demo6.ino'],['../_demo6_8ino.html#ad918c622cb258b19335463109f0b7996',1,'sleep_474(long t):&#160;Demo6.ino']]],
  ['speaker_5fsetup_5',['speaker_setup',['../_demo6_8ino.html#ae9b4ac841df7c446aec94564e5a75c95',1,'Demo6.ino']]],
  ['start_5ftask_6',['start_task',['../_d_d_s6_8h.html#a6affb1300e5212bd20dcfd2b3906a9d6',1,'start_task(tcb *task):&#160;Demo6.ino'],['../_demo6_8ino.html#a6affb1300e5212bd20dcfd2b3906a9d6',1,'start_task(tcb *task):&#160;Demo6.ino']]]
];
