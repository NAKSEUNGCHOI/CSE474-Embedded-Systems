var searchData=
[
  ['led_5fsetup_0',['LED_setup',['../_d_d_s6_8h.html#a1f3fa2515d36e9ac7322be1a414c48b1',1,'LED_setup():&#160;Demo6.ino'],['../_demo6_8ino.html#a1f3fa2515d36e9ac7322be1a414c48b1',1,'LED_setup():&#160;Demo6.ino']]],
  ['load_5fup_5ftask_1',['load_up_task',['../_d_d_s6_8h.html#ab3df8eee66c3971871f3c729cd24cfa3',1,'load_up_task(void(*arg_ptr)(), const char *):&#160;Demo6.ino'],['../_demo6_8ino.html#ac08bfa24a422790253e7afe7bec292eb',1,'load_up_task(void(*arg_ptr)(), const char *name):&#160;Demo6.ino']]],
  ['loop_2',['loop',['../_demo6_8ino.html#afe461d27b9c48d5921c00d521181f12f',1,'Demo6.ino']]]
];
