var searchData=
[
  ['dds_5fsetup_0',['DDS_setup',['../_demo6_8ino.html#acc9718b2f6f31adf68b2b0c5142b7dc7',1,'Demo6.ino']]],
  ['display_5fsegment_1',['display_segment',['../_d_d_s6_8h.html#a1e49f538059ec05fa3921fa26456f418',1,'display_segment(byte temp[7]):&#160;Demo6.ino'],['../_demo6_8ino.html#a1e49f538059ec05fa3921fa26456f418',1,'display_segment(byte temp[7]):&#160;Demo6.ino']]]
];
