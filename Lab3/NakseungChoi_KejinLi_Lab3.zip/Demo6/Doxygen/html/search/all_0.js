var searchData=
[
  ['convert_0',['convert',['../_d_d_s6_8h.html#a99ea858e3e8e2827660f4d0b5b165a73',1,'convert(int *digits, int temp):&#160;Demo6.ino'],['../_demo6_8ino.html#a99ea858e3e8e2827660f4d0b5b165a73',1,'convert(int *digits, int temp):&#160;Demo6.ino']]],
  ['copy_5ftcb_1',['copy_tcb',['../_d_d_s6_8h.html#a8dc212910f81b39145cfe2981d083271',1,'copy_tcb(tcb *running, tcb *dead):&#160;Demo6.ino'],['../_demo6_8ino.html#a8dc212910f81b39145cfe2981d083271',1,'copy_tcb(tcb *running, tcb *dead):&#160;Demo6.ino']]]
];
