var searchData=
[
  ['schedule_5fsync_0',['schedule_sync',['../_demo2_8ino.html#aa795a3f5ae7c3378d219ad1ca83a282d',1,'schedule_sync():&#160;Demo2.ino'],['../_s_r_r_i_8h.html#aa795a3f5ae7c3378d219ad1ca83a282d',1,'schedule_sync():&#160;Demo2.ino']]],
  ['set_5foc3a_5ffreq_1',['set_OC3A_freq',['../_demo2_8ino.html#a520643fae9a5bb426c0c6d4affa68a01',1,'set_OC3A_freq(uint32_t freq):&#160;Demo2.ino'],['../_s_r_r_i_8h.html#a520643fae9a5bb426c0c6d4affa68a01',1,'set_OC3A_freq(uint32_t freq):&#160;Demo2.ino']]],
  ['setup_2',['setup',['../_demo2_8ino.html#a4fc01d736fe50cf5b977f755b675f11d',1,'Demo2.ino']]],
  ['sleep_5f474_3',['sleep_474',['../_demo2_8ino.html#ad918c622cb258b19335463109f0b7996',1,'sleep_474(long t):&#160;Demo2.ino'],['../_s_r_r_i_8h.html#ad918c622cb258b19335463109f0b7996',1,'sleep_474(long t):&#160;Demo2.ino']]],
  ['speaker_5fsetup_4',['speaker_setup',['../_demo2_8ino.html#ae9b4ac841df7c446aec94564e5a75c95',1,'speaker_setup():&#160;Demo2.ino'],['../_s_r_r_i_8h.html#ae9b4ac841df7c446aec94564e5a75c95',1,'speaker_setup():&#160;Demo2.ino']]],
  ['srri_2eh_5',['SRRI.h',['../_s_r_r_i_8h.html',1,'']]]
];
