var searchData=
[
  ['dds_5fsetup_0',['DDS_setup',['../_demo5_8ino.html#acc9718b2f6f31adf68b2b0c5142b7dc7',1,'Demo5.ino']]],
  ['display_5fsegment_1',['display_segment',['../_demo5_8ino.html#a1e49f538059ec05fa3921fa26456f418',1,'Demo5.ino']]]
];
