var searchData=
[
  ['find_5fdead_5ftask_0',['find_dead_task',['../_d_d_s5_8h.html#aa27dc566869327e9f77b79072fd06294',1,'find_dead_task(const char *name):&#160;Demo5.ino'],['../_demo5_8ino.html#aa27dc566869327e9f77b79072fd06294',1,'find_dead_task(const char *name):&#160;Demo5.ino']]]
];
