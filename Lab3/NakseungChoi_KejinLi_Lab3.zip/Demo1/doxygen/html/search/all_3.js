var searchData=
[
  ['set_5foc3a_5ffreq_0',['set_OC3A_freq',['../_demo1_8ino.html#a520643fae9a5bb426c0c6d4affa68a01',1,'set_OC3A_freq(uint32_t freq):&#160;Demo1.ino'],['../_r_r_8h.html#a520643fae9a5bb426c0c6d4affa68a01',1,'set_OC3A_freq(uint32_t freq):&#160;Demo1.ino']]],
  ['setup_1',['setup',['../_demo1_8ino.html#a4fc01d736fe50cf5b977f755b675f11d',1,'Demo1.ino']]]
];
